package com.company.sales;

import java.util.HashMap;

public class Company {


	String name;
	HashMap<Integer,Double> salesPerson;
	HashMap<Client,Double> clients;  // Client:volume
	Double totalVolume;
	String topClientName;
	Double topClientVolume;
	String topSalesPerson;
	Double topSalesVolume;

	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getTotalVolume() {
		return totalVolume;
	}

	public void setTotalVolume(Double totalVolume) {
		this.totalVolume = totalVolume;
	}

	public String getTopClientName() {
		return topClientName;
	}

	public void setTopClientName(String topClientName) {
		this.topClientName = topClientName;
	}

	public Double getTopClientVolume() {
		return topClientVolume;
	}

	public void setTopClientVolume(Double topClientVolume) {
		this.topClientVolume = topClientVolume;
	}

	public String getTopSalesPerson() {
		return topSalesPerson;
	}

	public void setTopSalesPerson(String topSalesPerson) {
		this.topSalesPerson = topSalesPerson;
	}

	public Double getTopSalesVolume() {
		return topSalesVolume;
	}

	public void setTopSalesVolume(Double topSalesVolume) {
		this.topSalesVolume = topSalesVolume;
	}

	public Company(String name) {
		
		this.name = name;
		salesPerson = new HashMap<Integer,Double>();
		clients = new HashMap<Client,Double>();
		totalVolume =0.0;
		topClientVolume = 0.0;
		topSalesVolume = 0.0;
	}
	
	public void addClient(Client client) {
		
		if(!this.clients.containsKey(client))
			this.clients.put(client,0.0);
		
		return;
	}

	public void addTransaction(double cost, Client client, int salesPersonId,String salesPerson) {

		this.totalVolume+=cost;

		//Add client volume
		if(!this.clients.containsKey(client))
			this.clients.put(client, cost);
	
		else 
			this.clients.put(client, this.clients.get(client)+cost);
		
	// Add sales volume
		if(!this.salesPerson.containsKey(salesPersonId))
			this.salesPerson.put(salesPersonId, cost);
	
		else 
			this.salesPerson.put(salesPersonId, this.salesPerson.get(salesPersonId)+cost);
			
	
	//Check top Client
	
		double clientVolume = this.clients.get(client);
		if(clientVolume>this.topClientVolume) {
			this.topClientVolume= clientVolume;
			this.topClientName = client.getClientName();
			
		}
	//Check top salesPerson
		double salesVolume = this.salesPerson.get(salesPersonId);
		if(salesVolume>this.topSalesVolume) {
			this.topSalesVolume= salesVolume;
			this.topSalesPerson = salesPerson;
		}

	
	}	
	
	
}
