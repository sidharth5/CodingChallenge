package com.company.sales;

public class Client {

	int clientId;
	String clientName;
	String company;
	
	public int getClientId() {
		return clientId;
	}

	public void setClientId(int clientId) {
		this.clientId = clientId;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	
	Client(int clientId,String clientName,String company){
		
		this.clientId = clientId;
		this.company=company;
		this.clientName=clientName;
	}
}
