package com.company.sales;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class Salescalculator {

	public static void main(String[] args) throws ParseException {
		System.out.println("x");
		HashMap<String, Company> companies = new HashMap<String, Company>();
		HashMap<Integer, String> salesPerson = new HashMap<Integer, String>();
		HashMap<String, Float> conversions = new HashMap<String, Float>();
		HashMap<Integer,Client> clients = new HashMap<Integer, Client>();
		
		
		getClients(companies,clients);
		getSalesPerson(salesPerson);
		getConversions(conversions);
		getTransactions(companies,salesPerson,conversions,clients);
		
		 try {
	         BufferedWriter out = new BufferedWriter(new FileWriter("result.dat"));

		//Top Client Name, Total Transacted USD Volume of Top Client,
		
		for(String company : companies.keySet()) {
			
			String salesName = companies.get(company).getTopSalesPerson();
			double totalVolume = companies.get(company).getTotalVolume();
			String clientName = companies.get(company).getTopClientName();
			double totalClientVolume = companies.get(company).getTopClientVolume();
	        String result = ""+ company+";"+salesName+";"+totalVolume+";"+clientName+";"+totalClientVolume+"\n";
			out.write(result);
			
		}
        out.close();
        System.out.println("File created successfully");
     
	}
	   catch (IOException e) {
	   }	
		 
}
	
	
	
	

	public static void getClients(HashMap<String, Company> companies, HashMap<Integer, Client> clients) {

		String csvFile = "C://salesReportExercise/client.data";
		BufferedReader br = null;
		String line = "";
		String SplitBy = ";";
		try {

			br = new BufferedReader(new FileReader(csvFile));
			br.readLine();
			while ((line = br.readLine()) != null) {

				// client[4] = companyName
				// client[0] = client id
				// client[1] = client name
				
				String[] client = line.split(SplitBy);

				Client c = new Client(Integer.parseInt(client[0]),client[1],client[4]);
				
				if(!clients.containsKey(client[0]))
					clients.put(Integer.parseInt(client[0]), c);
				
				String company = client[4];
				if (!companies.containsKey(company))
					companies.put(company, new Company(company));

				companies.get(company).addClient(c);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void getSalesPerson(HashMap<Integer, String> salesPerson) {

		String csvFile = "salesReportExercise/sales.data";
		BufferedReader br = null;
		String line = "";
		String SplitBy = ";";
		try {

			br = new BufferedReader(new FileReader(csvFile));
			br.readLine();
			while ((line = br.readLine()) != null) {
				String[] sales = line.split(SplitBy);
				if (!salesPerson.containsKey(Integer.parseInt(sales[1])))
					salesPerson.put(Integer.parseInt(sales[1]), sales[0]);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static void getConversions(HashMap<String, Float> converstions) {

		String csvFile = "salesReportExercise/ccy.data";
		BufferedReader br = null;
		String line = "";
		String SplitBy = ";";
		try {

			br = new BufferedReader(new FileReader(csvFile));
			br.readLine();
			while ((line = br.readLine()) != null) {
				String[] conversion = line.split(SplitBy);
				if (!converstions.containsKey(conversion[0]))
					converstions.put(conversion[0], Float.parseFloat(conversion[1]));
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}


	public static void getTransactions(HashMap<String, Company> companies,	HashMap<Integer, String> salesPerson, HashMap<String, Float> conversions, HashMap<Integer, Client> clients) throws ParseException {

		String csvFile = "salesReportExercise/transaction.data";
		BufferedReader br = null;
		String line = "";
		String SplitBy = ";";
		try {

			br = new BufferedReader(new FileReader(csvFile));
			br.readLine();
			while ((line = br.readLine()) != null) {
				String[] transaction = line.split(SplitBy);
				String[] date = transaction[1].split("/");
				String year = date[2];

				 if(year.contentEquals("2019")) {
					 
					 int clientId = Integer.parseInt(transaction[4]);
					 String company = clients.get(clientId).getCompany();
					 
					 int costOriginal = Integer.parseInt(transaction[3]);

					 String currency = transaction[2];
					 float rate = conversions.get(currency);
					 double cost = costOriginal*rate;
					 
					//System.out.println(cost);

					 int salesPersonId = Integer.parseInt(transaction[5]);
					 companies.get(company).addTransaction(cost,clients.get(clientId),salesPersonId,salesPerson.get(salesPersonId));
				 }
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	
	
}
